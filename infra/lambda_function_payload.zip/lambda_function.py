import json
import urllib.request
import os
import logging
import traceback

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    # Get the config server URL from environment variable
    config_server_url = os.environ['CONFIG_SERVER_URL']

    logger.info(f"Received S3 event: {json.dumps(event)}")

    try:
        # Create a POST request to the config server
        req = urllib.request.Request(
            config_server_url,
            data=b'',  # Empty data for POST request
            method='POST'
        )

        # Add headers if needed
        req.add_header('Content-Type', 'application/json')

        # Send the request
        logger.info(f"Sending POST request to {config_server_url}")
        with urllib.request.urlopen(req) as response:
            response_body = response.read().decode('utf-8')
            logger.info(f"Response status: {response.status}")
            logger.info(f"Response body: {response_body}")

        return {
            'statusCode': 200,
            'body': json.dumps('Config server refresh triggered successfully')
        }
    except Exception as e:
        logger.error(f"Error triggering config server refresh: {str(e)}")
        traceback.print_exc()
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error: {str(e)}')
        }
